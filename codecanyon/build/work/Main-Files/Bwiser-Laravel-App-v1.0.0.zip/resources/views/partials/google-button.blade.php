@php
    $href = $href ?? route('auth.google.redirect');
    $label = $label ?? 'Continue with Google';
    $class = $class ?? '';
@endphp

@once
<style>
    .google-glow-button {
        background: #000;
        color: #fff;
        font-size: 1rem;
        padding: 0.85rem 1.25rem;
        border-radius: 999px;
        border: none;
        position: relative;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        font-weight: 600;
        text-decoration: none;
        overflow: hidden;
    }

    .google-glow-button::before {
        --vibrance: 0.2;
        content: "";
        position: absolute;
        inset: 10px 10px -10px;
        background: linear-gradient(90deg, rgba(255, 255, 255, calc(0.4 + var(--vibrance))), rgba(0, 255, 255, 0.45), rgba(255, 0, 255, 0.45));
        filter: blur(20px);
        border-radius: inherit;
        z-index: -1;
        opacity: 0.9;
    }

    .google-glow-button:hover {
        transform: translateY(-1px);
    }
</style>
@endonce

<a href="{{ $href }}" class="google-glow-button {{ $class }}">
    <svg class="mr-2 h-5 w-5" viewBox="0 0 48 48" aria-hidden="true">
        <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.6 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.7 1.1 7.8 2.9l5.7-5.7C34 6 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.2-.1-2.3-.4-3.5z"/>
        <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 18.9 12 24 12c3 0 5.7 1.1 7.8 2.9l5.7-5.7C34 6 29.3 4 24 4c-7.7 0-14.3 4.3-17.7 10.7z"/>
        <path fill="#4CAF50" d="M24 44c5.2 0 10-2 13.5-5.3l-6.2-5.2C29.3 35 26.8 36 24 36c-5.2 0-9.6-3.3-11.2-8l-6.6 5.1C9.5 39.6 16.2 44 24 44z"/>
        <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.3-4 5.7l.1-.1 6.2 5.2C37.2 39.1 44 34 44 24c0-1.2-.1-2.3-.4-3.5z"/>
    </svg>
    {{ $label }}
</a>
