@extends('layouts.app')

@section('title', 'Repayments - Bwiser')

@section('content')
<section class="max-w-6xl mx-auto px-6 pt-16 pb-20">
    <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
            <p class="text-sm uppercase tracking-[0.2em] text-blue-600">Driver Portal</p>
            <h1 class="brand-font text-3xl font-semibold text-slate-900 mt-2">Repayments</h1>
            <p class="text-slate-600 mt-2">Track dues and pay outstanding amounts via Paystack.</p>
        </div>
        <a href="{{ route('driver.dashboard') }}" class="btn-ghost px-4 py-2.5 rounded-xl text-sm font-semibold">Back to Dashboard</a>
    </div>
    @include('driver.partials.nav', ['backUrl' => route('driver.dashboard')])

    @if(session('error'))
        <div class="mt-6 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
            {{ session('error') }}
        </div>
    @endif

    <div class="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div class="glass rounded-2xl p-5">
            <p class="text-sm text-slate-500">Pending Items</p>
            <p class="text-2xl font-semibold text-slate-900 mt-2">{{ $summary['pending_count'] }}</p>
        </div>
        <div class="glass rounded-2xl p-5">
            <p class="text-sm text-slate-500">Outstanding Amount</p>
            <p class="text-2xl font-semibold text-slate-900 mt-2">R {{ number_format((float) $summary['pending_amount'], 2) }}</p>
        </div>
        <div class="glass rounded-2xl p-5">
            <p class="text-sm text-slate-500">Paid This Month</p>
            <p class="text-2xl font-semibold text-slate-900 mt-2">R {{ number_format((float) $summary['paid_this_month'], 2) }}</p>
        </div>
    </div>

    <div class="glass rounded-2xl mt-6 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full text-sm">
                <thead class="bg-slate-50 text-slate-600">
                    <tr>
                        <th class="px-4 py-3 text-left">Due Date</th>
                        <th class="px-4 py-3 text-left">Amount</th>
                        <th class="px-4 py-3 text-left">Lease</th>
                        <th class="px-4 py-3 text-left">Station</th>
                        <th class="px-4 py-3 text-left">Status</th>
                        <th class="px-4 py-3 text-left">Action</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 bg-white">
                    @forelse($repayments as $repayment)
                        @php
                            $stationName = optional(optional($repayment->lease)->vouchers->first())->fuelStation->name ?? 'N/A';
                            $isActivated = collect(optional($repayment->lease)->vouchers)
                                ->contains(fn ($voucher) => $voucher->status === 'redeemed');
                        @endphp
                        <tr>
                            <td class="px-4 py-3 text-slate-700">{{ \Illuminate\Support\Carbon::parse($repayment->due_date)->format('d M Y') }}</td>
                            <td class="px-4 py-3 font-medium text-slate-900">R {{ number_format((float) $repayment->amount, 2) }}</td>
                            <td class="px-4 py-3 text-slate-700">#{{ $repayment->lease_id }}</td>
                            <td class="px-4 py-3 text-slate-700">{{ $stationName }}</td>
                            <td class="px-4 py-3">
                                @if($isActivated)
                                    <span class="text-xs px-2 py-1 rounded-full bg-slate-100 text-slate-700 uppercase">{{ $repayment->status }}</span>
                                @else
                                    <span class="text-xs px-2 py-1 rounded-full bg-amber-100 text-amber-700">Awaiting voucher redemption</span>
                                @endif
                            </td>
                            <td class="px-4 py-3">
                                @if(in_array($repayment->status, ['pending', 'overdue'], true) && $isActivated)
                                    <form method="POST" action="{{ route('payments.paystack.repayment', $repayment) }}" class="flex flex-wrap gap-2">
                                        @csrf
                                        <button name="payment_method" value="apple_pay" class="px-3 py-2 rounded-lg text-xs font-semibold bg-black text-white hover:bg-slate-800">
                                            <i class="fab fa-apple mr-1"></i> Apple Pay
                                        </button>
                                        <button name="payment_method" value="google_pay" class="px-3 py-2 rounded-lg text-xs font-semibold bg-white border border-slate-300 text-slate-800 hover:bg-slate-50">
                                            <i class="fab fa-google mr-1"></i> Google Pay
                                        </button>
                                        <button name="payment_method" value="card" class="btn-primary px-3 py-2 rounded-lg text-xs font-semibold">Card</button>
                                    </form>
                                @elseif(!in_array($repayment->status, ['pending', 'overdue'], true))
                                    <span class="text-xs text-emerald-600 font-medium">Paid</span>
                                @else
                                    <span class="text-xs text-amber-700 font-medium">Locked</span>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="px-4 py-8 text-center text-slate-500">No repayment records found.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="px-4 py-4 bg-white border-t border-slate-100">
            {{ $repayments->links() }}
        </div>
    </div>
</section>
@endsection
