@extends('layouts.admin')

@section('title', 'Direct Bank Deposit #' . $settlement->id)
@section('page-title', 'Direct Bank Deposit Details')
@section('page-description', 'Review and complete direct bank deposit payment')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.settlements.index') }}">Direct Bank Deposits</a></li>
<li class="breadcrumb-item active">Direct Bank Deposit #{{ $settlement->id }}</li>
@endsection

@section('content')
<div class="p-6">
    <div class="max-w-6xl mx-auto space-y-6">
        <div class="flex items-center justify-between">
            <div>
                <h2 class="text-2xl font-bold text-gray-900">Direct Bank Deposit #{{ $settlement->id }}</h2>
                <p class="text-gray-600 mt-1">Reference: {{ $settlement->reference }}</p>
            </div>
            <a href="{{ route('admin.settlements.index') }}" class="text-blue-600 hover:text-blue-800 no-print">
                <i class="fas fa-arrow-left mr-2"></i>Back to direct bank deposits
            </a>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2 space-y-6 print-full">
                <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Direct Bank Deposit Summary</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-700">
                        <div>
                            <p class="text-gray-500">Fuel Station</p>
                            <p class="font-semibold">{{ $settlement->fuelStation->name }}</p>
                        </div>
                        <div>
                            <p class="text-gray-500">Amount</p>
                            <p class="font-semibold">ZAR {{ number_format($settlement->amount, 2) }}</p>
                        </div>
                        <div>
                            <p class="text-gray-500">Status</p>
                            <span class="inline-flex px-3 py-1 rounded-full text-xs font-semibold
                                {{ $settlement->status === 'completed' ? 'bg-green-100 text-green-700' : ($settlement->status === 'failed' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700') }}">
                                {{ ucfirst($settlement->status) }}
                            </span>
                        </div>
                        <div>
                            <p class="text-gray-500">Direct Bank Deposit Date</p>
                            <p class="font-semibold">{{ $settlement->settlement_date?->format('M d, Y') ?? '—' }}</p>
                        </div>
                        <div>
                            <p class="text-gray-500">Transaction Ref</p>
                            <p class="font-semibold">{{ $settlement->transaction_reference ?? '—' }}</p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Notes</h3>
                    <p class="text-sm text-gray-700">{{ $settlement->notes ?? '—' }}</p>
                </div>
            </div>

            <div class="space-y-6 no-print">
                <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Actions</h3>

                    @if($settlement->status === 'pending')
                        <form method="POST" action="{{ route('admin.settlements.paystack-checkout', $settlement) }}" class="space-y-2">
                            @csrf
                            <button type="submit" name="payment_method" value="apple_pay" class="w-full px-4 py-2 bg-black text-white rounded-xl text-sm font-semibold hover:bg-slate-800">
                                <i class="fab fa-apple mr-1"></i> Pay with Apple Pay
                            </button>
                            <button type="submit" name="payment_method" value="google_pay" class="w-full px-4 py-2 bg-white border border-gray-300 text-gray-800 rounded-xl text-sm font-semibold hover:bg-gray-50">
                                <i class="fab fa-google mr-1"></i> Pay with Google Pay
                            </button>
                            <button type="submit" name="payment_method" value="card" class="w-full px-4 py-3 bg-green-600 text-white rounded-xl font-semibold hover:bg-green-700">
                                Pay with Card (Paystack)
                            </button>
                        </form>
                    @else
                        <div class="text-sm text-gray-500">
                            This direct bank deposit is {{ $settlement->status }}.
                        </div>
                    @endif

                    @if($settlement->status === 'pending')
                        <form method="POST" action="{{ route('admin.settlements.mark-as-failed', $settlement) }}" class="mt-6">
                            @csrf
                            <label class="block text-sm text-gray-600 mb-2">Failure Reason</label>
                            <textarea name="reason" rows="3" class="w-full border border-gray-300 rounded-lg px-3 py-2 mb-3" required></textarea>
                            <button type="submit" class="w-full px-4 py-2 bg-red-100 text-red-700 rounded-lg font-semibold hover:bg-red-200">
                                Mark as Failed
                            </button>
                        </form>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@if(request()->boolean('print'))
    @push('styles')
        <style>
            @media print {
                #sidebar,
                header,
                footer,
                .no-print {
                    display: none !important;
                }
                .content-area {
                    margin-left: 0 !important;
                }
                .print-full {
                    grid-column: 1 / -1;
                }
                body {
                    background: #ffffff !important;
                }
            }
        </style>
    @endpush
    @push('scripts')
        <script>
            window.addEventListener('load', () => window.print());
        </script>
    @endpush
@endif
