@extends('layouts.admin')

@section('title', 'Dashboard')
@section('page-title', 'Dashboard Overview')

@section('content')
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
    <!-- Stats Cards -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center">
            <div class="p-3 rounded-full bg-blue-100 text-blue-600 mr-4">
                <i class="fas fa-users text-2xl"></i>
            </div>
            <div>
                <p class="text-sm text-gray-600">Total Users</p>
                <p class="text-2xl font-bold">{{ $stats['total_users'] ?? 0 }}</p>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center">
            <div class="p-3 rounded-full bg-green-100 text-green-600 mr-4">
                <i class="fas fa-gas-pump text-2xl"></i>
            </div>
            <div>
                <p class="text-sm text-gray-600">Active Stations</p>
                <p class="text-2xl font-bold">{{ $stats['active_stations'] ?? 0 }}</p>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center">
            <div class="p-3 rounded-full bg-yellow-100 text-yellow-600 mr-4">
                <i class="fas fa-ticket-alt text-2xl"></i>
            </div>
            <div>
                <p class="text-sm text-gray-600">Pending Vouchers</p>
                <p class="text-2xl font-bold">{{ $stats['pending_vouchers'] ?? 0 }}</p>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center">
            <div class="p-3 rounded-full bg-red-100 text-red-600 mr-4">
                <i class="fas fa-money-bill-wave text-2xl"></i>
            </div>
            <div>
                <p class="text-sm text-gray-600">Total Settlements</p>
                <p class="text-2xl font-bold">ZAR {{ number_format($stats['total_settlement_amount'] ?? 0, 2) }}</p>
            </div>
        </div>
    </div>
</div>

<!-- Welcome Card -->
<div class="mb-8 bg-white rounded-lg shadow p-6">
    <div class="flex items-center">
        <div class="p-3 rounded-full bg-blue-100 text-blue-600 mr-4">
            <i class="fas fa-user text-2xl"></i>
        </div>
        <div>
            <h3 class="text-lg font-semibold">Welcome, {{ auth()->user()->name }}!</h3>
            <p class="text-gray-600">You are logged in as {{ auth()->user()->getRoleNames()->first() ?? 'User' }}</p>
            <p class="text-sm text-gray-500 mt-1">Email: {{ auth()->user()->email }}</p>
            <p class="text-sm text-gray-500">Last login: {{ auth()->user()->last_login_at ? auth()->user()->last_login_at->diffForHumans() : 'First login' }}</p>
        </div>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    <!-- Recent Vouchers -->
    <div class="bg-white rounded-lg shadow">
        <div class="px-6 py-4 border-b">
            <h3 class="text-lg font-semibold">Recent Vouchers</h3>
        </div>
        <div class="p-6">
            @if($recent_vouchers->count() > 0)
            <div class="space-y-4">
                @foreach($recent_vouchers as $voucher)
                <div class="flex items-center justify-between border-b pb-3">
                    <div>
                        <p class="font-medium">{{ $voucher->code }}</p>
                        <p class="text-sm text-gray-600">{{ $voucher->user->name ?? 'Unknown User' }}</p>
                    </div>
                    <div class="text-right">
                        <p class="font-bold">ZAR {{ number_format($voucher->amount, 2) }}</p>
                        <span class="text-xs px-2 py-1 rounded-full 
                            @if($voucher->status == 'issued') bg-yellow-100 text-yellow-800
                            @elseif($voucher->status == 'redeemed') bg-green-100 text-green-800
                            @else bg-gray-100 text-gray-800 @endif">
                            {{ ucfirst($voucher->status) }}
                        </span>
                    </div>
                </div>
                @endforeach
            </div>
            <div class="mt-4 text-center">
                <a href="{{ route('admin.vouchers.index') }}" class="text-blue-600 hover:underline">View All Vouchers</a>
            </div>
            @else
            <div class="text-center py-8">
                <i class="fas fa-ticket-alt text-gray-300 text-4xl mb-4"></i>
                <p class="text-gray-500">No vouchers found</p>
            </div>
            @endif
        </div>
    </div>

    <!-- Recent Users -->
    <div class="bg-white rounded-lg shadow">
        <div class="px-6 py-4 border-b">
            <h3 class="text-lg font-semibold">Recent Users</h3>
        </div>
        <div class="p-6">
            @if($recent_users->count() > 0)
            <div class="space-y-4">
                @foreach($recent_users as $user)
                <div class="flex items-center justify-between border-b pb-3">
                    <div>
                        <p class="font-medium">{{ $user->name }}</p>
                        <p class="text-sm text-gray-600">{{ $user->email }}</p>
                    </div>
                    <div class="text-right">
                        <span class="text-xs px-2 py-1 rounded-full 
                            @if($user->status == 'active') bg-green-100 text-green-800
                            @elseif($user->status == 'suspended') bg-red-100 text-red-800
                            @else bg-gray-100 text-gray-800 @endif">
                            {{ ucfirst($user->status) }}
                        </span>
                        <p class="text-sm text-gray-600 mt-1">Score: {{ $user->credit_score }}</p>
                    </div>
                </div>
                @endforeach
            </div>
            <div class="mt-4 text-center">
                <a href="{{ route('admin.users.index') }}" class="text-blue-600 hover:underline">View All Users</a>
            </div>
            @else
            <div class="text-center py-8">
                <i class="fas fa-users text-gray-300 text-4xl mb-4"></i>
                <p class="text-gray-500">No users found</p>
            </div>
            @endif
        </div>
    </div>
</div>

<div class="mt-8 bg-white rounded-lg shadow p-6">
    <h3 class="text-lg font-semibold mb-4">Quick Actions</h3>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <a href="{{ route('admin.users.create') }}" 
           class="bg-blue-50 hover:bg-blue-100 p-4 rounded-lg text-center transition duration-200">
            <i class="fas fa-user-plus text-blue-600 text-2xl mb-2"></i>
            <p class="font-medium">Add New User</p>
            <p class="text-sm text-gray-600 mt-1">Create new system user</p>
        </a>
        
        <a href="{{ route('admin.vouchers.pending') }}" 
           class="bg-yellow-50 hover:bg-yellow-100 p-4 rounded-lg text-center transition duration-200">
            <i class="fas fa-check-circle text-yellow-600 text-2xl mb-2"></i>
            <p class="font-medium">Approve Vouchers</p>
            <p class="text-sm text-gray-600 mt-1">Review pending vouchers</p>
        </a>
        
        <a href="{{ route('admin.settlements.index') }}" 
           class="bg-green-50 hover:bg-green-100 p-4 rounded-lg text-center transition duration-200">
            <i class="fas fa-money-check-alt text-green-600 text-2xl mb-2"></i>
            <p class="font-medium">Process Settlements</p>
            <p class="text-sm text-gray-600 mt-1">Manage station payouts</p>
        </a>
    </div>
</div>

<div class="mt-8 grid grid-cols-1 xl:grid-cols-2 gap-6">
    <div class="rounded-lg bg-white p-6 shadow">
        <form action="{{ route('admin.feedback.store') }}" method="POST" class="grid grid-cols-6 gap-3 rounded-md bg-white p-3 shadow-md">
            @csrf
            <h1 class="col-span-6 text-2xl font-bold capitalize text-slate-400">
                feedback
            </h1>
            <textarea
                name="feedback"
                required
                class="col-span-6 min-h-28 resize-none bg-slate-100 p-2 outline-none ring-2 ring-slate-200 duration-300 placeholder:text-slate-400 focus:ring-slate-400 rounded-md text-slate-500"
                placeholder="What's Your Feedback?"
            >{{ old('feedback') }}</textarea>

            <input type="hidden" name="sentiment" id="feedbackSentiment" value="{{ old('sentiment', 'neutral') }}">

            <button
                type="button"
                id="feedbackPositiveBtn"
                class="flex items-center justify-center bg-slate-100 p-2 ring-2 ring-slate-200 duration-300 focus:ring-slate-400 rounded-md"
            >
                <svg viewBox="0 0 512 512" height="20px" xmlns="http://www.w3.org/2000/svg" class="fill-slate-500">
                    <path d="M464 256A208 208 0 1 0 48 256a208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm177.6 62.1C192.8 334.5 218.8 352 256 352s63.2-17.5 78.4-33.9c9-9.7 24.2-10.4 33.9-1.4s10.4 24.2 1.4 33.9c-22 23.8-60 49.4-113.6 49.4s-91.7-25.5-113.6-49.4c-9-9.7-8.4-24.9 1.4-33.9s24.9-8.4 33.9 1.4zm40-89.3l0 0 0 0-.2-.2c-.2-.2-.4-.5-.7-.9c-.6-.8-1.6-2-2.8-3.4c-2.5-2.8-6-6.6-10.2-10.3c-8.8-7.8-18.8-14-27.7-14s-18.9 6.2-27.7 14c-4.2 3.7-7.7 7.5-10.2 10.3c-1.2 1.4-2.2 2.6-2.8 3.4c-.3 .4-.6 .7-.7 .9l-.2 .2 0 0 0 0 0 0c-2.1 2.8-5.7 3.9-8.9 2.8s-5.5-4.1-5.5-7.6c0-17.9 6.7-35.6 16.6-48.8c9.8-13 23.9-23.2 39.4-23.2s29.6 10.2 39.4 23.2c9.9 13.2 16.6 30.9 16.6 48.8c0 3.4-2.2 6.5-5.5 7.6s-6.9 0-8.9-2.8l0 0 0 0zm160 0l0 0-.2-.2c-.2-.2-.4-.5-.7-.9c-.6-.8-1.6-2-2.8-3.4c-2.5-2.8-6-6.6-10.2-10.3c-8.8-7.8-18.8-14-27.7-14s-18.9 6.2-27.7 14c-4.2 3.7-7.7 7.5-10.2 10.3c-1.2 1.4-2.2 2.6-2.8 3.4c-.3 .4-.6 .7-.7 .9l-.2 .2 0 0 0 0 0 0c-2.1 2.8-5.7 3.9-8.9 2.8s-5.5-4.1-5.5-7.6c0-17.9 6.7-35.6 16.6-48.8c9.8-13 23.9-23.2 39.4-23.2s29.6 10.2 39.4 23.2c9.9 13.2 16.6 30.9 16.6 48.8c0 3.4-2.2 6.5-5.5 7.6s-6.9 0-8.9-2.8l0 0 0 0 0 0z"></path>
                </svg>
            </button>
            <button
                type="button"
                id="feedbackNegativeBtn"
                class="flex items-center justify-center bg-slate-100 p-2 ring-2 ring-slate-200 duration-300 focus:ring-slate-400 rounded-md"
            >
                <svg viewBox="0 0 512 512" height="20px" xmlns="http://www.w3.org/2000/svg" class="fill-slate-500">
                    <path d="M464 256A208 208 0 1 0 48 256a208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zM174.6 384.1c-4.5 12.5-18.2 18.9-30.7 14.4s-18.9-18.2-14.4-30.7C146.9 319.4 198.9 288 256 288s109.1 31.4 126.6 79.9c4.5 12.5-2 26.2-14.4 30.7s-26.2-2-30.7-14.4C328.2 358.5 297.2 336 256 336s-72.2 22.5-81.4 48.1zM144.4 208a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm192-32a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"></path>
                </svg>
            </button>
            <hr class="col-span-2 border-none" />
            <button
                type="submit"
                class="col-span-2 flex items-center justify-center bg-slate-100 p-2 ring-2 ring-slate-200 duration-300 hover:ring-slate-400 rounded-md"
            >
                <svg viewBox="0 0 512 512" height="20px" xmlns="http://www.w3.org/2000/svg" class="fill-slate-500">
                    <path d="M16.1 260.2c-22.6 12.9-20.5 47.3 3.6 57.3L160 376V479.3c0 18.1 14.6 32.7 32.7 32.7c9.7 0 18.9-4.3 25.1-11.8l62-74.3 123.9 51.6c18.9 7.9 40.8-4.5 43.9-24.7l64-416c1.9-12.1-3.4-24.3-13.5-31.2s-23.3-7.5-34-1.4l-448 256zm52.1 25.5L409.7 90.6 190.1 336l1.2 1L68.2 285.7zM403.3 425.4L236.7 355.9 450.8 116.6 403.3 425.4z"></path>
                </svg>
            </button>
        </form>
    </div>

    <div class="rounded-lg bg-white p-6 shadow">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">Recent Feedback</h3>
        <div class="space-y-3">
            @forelse(($recent_feedback ?? collect()) as $item)
                <div class="rounded-md border border-slate-200 bg-slate-50 p-3">
                    <div class="flex items-center justify-between gap-3">
                        <p class="text-sm font-semibold text-slate-800">{{ $item->user?->name ?? 'System User' }}</p>
                        <span class="text-xs font-semibold px-2 py-1 rounded-full {{ $item->sentiment === 'positive' ? 'bg-emerald-100 text-emerald-700' : ($item->sentiment === 'negative' ? 'bg-rose-100 text-rose-700' : 'bg-slate-200 text-slate-700') }}">
                            {{ strtoupper($item->sentiment) }}
                        </span>
                    </div>
                    <p class="text-sm text-slate-600 mt-2">{{ $item->message }}</p>
                    <p class="text-xs text-slate-400 mt-2">{{ $item->created_at?->diffForHumans() }}</p>
                </div>
            @empty
                <p class="text-sm text-slate-500">No feedback submitted yet.</p>
            @endforelse
        </div>
    </div>
</div>

<!-- System Status -->
<div class="mt-8 bg-white rounded-lg shadow p-6">
    <h3 class="text-lg font-semibold mb-4">System Status</h3>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="flex items-center">
            <div class="p-2 rounded-full bg-green-100 text-green-600 mr-3">
                <i class="fas fa-database"></i>
            </div>
            <div>
                <p class="text-sm text-gray-600">Database</p>
                <p class="font-medium">Online</p>
            </div>
        </div>
        
        <div class="flex items-center">
            <div class="p-2 rounded-full bg-green-100 text-green-600 mr-3">
                <i class="fas fa-server"></i>
            </div>
            <div>
                <p class="text-sm text-gray-600">Server</p>
                <p class="font-medium">Running</p>
            </div>
        </div>
        
        <div class="flex items-center">
            <div class="p-2 rounded-full bg-blue-100 text-blue-600 mr-3">
                <i class="fas fa-shield-alt"></i>
            </div>
            <div>
                <p class="text-sm text-gray-600">Security</p>
                <p class="font-medium">Active</p>
            </div>
        </div>
        
        <div class="flex items-center">
            <div class="p-2 rounded-full bg-blue-100 text-blue-600 mr-3">
                <i class="fas fa-sync-alt"></i>
            </div>
            <div>
                <p class="text-sm text-gray-600">Last Updated</p>
                <p class="font-medium">{{ now()->format('M d, Y H:i') }}</p>
            </div>
        </div>
    </div>
</div>

<script>
    (function initAdminFeedbackSentiment() {
        const sentimentInput = document.getElementById('feedbackSentiment');
        const positiveBtn = document.getElementById('feedbackPositiveBtn');
        const negativeBtn = document.getElementById('feedbackNegativeBtn');
        if (!sentimentInput || !positiveBtn || !negativeBtn) return;

        const applyState = (value) => {
            sentimentInput.value = value;

            positiveBtn.classList.remove('ring-emerald-400', 'bg-emerald-50');
            negativeBtn.classList.remove('ring-rose-400', 'bg-rose-50');

            if (value === 'positive') {
                positiveBtn.classList.add('ring-emerald-400', 'bg-emerald-50');
            } else if (value === 'negative') {
                negativeBtn.classList.add('ring-rose-400', 'bg-rose-50');
            }
        };

        positiveBtn.addEventListener('click', () => applyState('positive'));
        negativeBtn.addEventListener('click', () => applyState('negative'));
        applyState(sentimentInput.value || 'neutral');
    })();
</script>
@endsection
