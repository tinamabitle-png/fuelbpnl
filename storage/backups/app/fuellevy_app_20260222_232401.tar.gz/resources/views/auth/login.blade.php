<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Fuel BNPL</title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .bg-gradient {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-md w-full">
            <!-- Logo & Title -->
            <div class="text-center mb-8">
                <div class="flex justify-center mb-4">
                    <div class="bg-blue-600 p-4 rounded-full">
                        <i class="fas fa-gas-pump text-white text-3xl"></i>
                    </div>
                </div>
                <h2 class="text-3xl font-bold text-gray-900">Fuel BNPL</h2>
                <p class="mt-2 text-gray-600">Buy Now, Pay Later for Fuel</p>
                <p class="mt-1 text-sm text-gray-500">Sign in to your account</p>
            </div>

            <!-- Login Form -->
            <div class="bg-white py-8 px-6 shadow rounded-lg sm:px-10">
                <form class="space-y-6" action="{{ route('login') }}" method="POST">
                    @csrf
                    
                    @if($errors->any())
                        <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-4">
                            <div class="flex">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-exclamation-circle text-red-500"></i>
                                </div>
                                <div class="ml-3">
                                    <p class="text-sm text-red-700">
                                        {{ $errors->first() }}
                                    </p>
                                </div>
                            </div>
                        </div>
                    @endif

                    @if(session('status'))
                        <div class="bg-green-50 border-l-4 border-green-500 p-4 mb-4">
                            <div class="flex">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-check-circle text-green-500"></i>
                                </div>
                                <div class="ml-3">
                                    <p class="text-sm text-green-700">
                                        {{ session('status') }}
                                    </p>
                                </div>
                            </div>
                        </div>
                    @endif

                    <div>
                        <label for="email" class="block text-sm font-medium text-gray-700">
                            Email Address
                        </label>
                        <div class="mt-1 relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-envelope text-gray-400"></i>
                            </div>
                            <input id="email" name="email" type="email" autocomplete="email" required
                                   value="{{ old('email') }}"
                                   class="pl-10 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm 
                                          placeholder-gray-400 focus:outline-none focus:ring-blue-500 
                                          focus:border-blue-500 sm:text-sm"
                                   placeholder="you@example.com">
                        </div>
                    </div>

                    <div>
                        <label for="password" class="block text-sm font-medium text-gray-700">
                            Password
                        </label>
                        <div class="mt-1 relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-lock text-gray-400"></i>
                            </div>
                            <input id="password" name="password" type="password" autocomplete="current-password" required
                                   class="pl-10 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm 
                                          placeholder-gray-400 focus:outline-none focus:ring-blue-500 
                                          focus:border-blue-500 sm:text-sm"
                                   placeholder="••••••••">
                        </div>
                    </div>

                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <input id="remember" name="remember" type="checkbox"
                                   class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                            <label for="remember" class="ml-2 block text-sm text-gray-900">
                                Remember me
                            </label>
                        </div>

                        <div class="text-sm">
                            <a href="#" class="font-medium text-blue-600 hover:text-blue-500">
                                Forgot password?
                            </a>
                        </div>
                    </div>

                    <div>
                        <button type="submit"
                                class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md 
                                       shadow-sm text-sm font-medium text-white bg-gradient hover:bg-blue-700 
                                       focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            <i class="fas fa-sign-in-alt mr-2"></i>
                            Sign in
                        </button>
                    </div>
                </form>

                <div class="mt-6">
                    <div class="relative">
                        <div class="absolute inset-0 flex items-center">
                            <div class="w-full border-t border-gray-300"></div>
                        </div>
                        <div class="relative flex justify-center text-sm">
                            <span class="px-2 bg-white text-gray-500">Demo Credentials</span>
                        </div>
                    </div>

                    <div class="mt-4 grid grid-cols-1 gap-3">
                        <div class="bg-gray-50 p-4 rounded-lg">
                            <h4 class="text-sm font-medium text-gray-900 mb-2">Super Admin</h4>
                            <p class="text-xs text-gray-600">Email: admin@fuelbnpl.com</p>
                            <p class="text-xs text-gray-600">Password: Admin123!</p>
                        </div>
                        
                        <div class="bg-gray-50 p-4 rounded-lg">
                            <h4 class="text-sm font-medium text-gray-900 mb-2">Employee</h4>
                            <p class="text-xs text-gray-600">Email: employee@fuelbnpl.com</p>
                            <p class="text-xs text-gray-600">Password: Employee123!</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-8 text-center">
                <p class="text-sm text-gray-600">
                    © {{ date('Y') }} Fuel BNPL. All rights reserved.
                </p>
            </div>
        </div>
    </div>

    <!-- Script for demo fill -->
    <script>
        // Demo fill functionality (optional)
        function fillDemo(type) {
            if (type === 'admin') {
                document.getElementById('email').value = 'admin@fuelbnpl.com';
                document.getElementById('password').value = 'Admin123!';
            } else if (type === 'employee') {
                document.getElementById('email').value = 'employee@fuelbnpl.com';
                document.getElementById('password').value = 'Employee123!';
            }
        }
        
        // Auto-fill admin credentials on page load (for demo purposes)
        document.addEventListener('DOMContentLoaded', function() {
            // Uncomment to auto-fill admin credentials
            // document.getElementById('email').value = 'admin@fuelbnpl.com';
            // document.getElementById('password').value = 'Admin123!';
        });
    </script>
</body>
</html>