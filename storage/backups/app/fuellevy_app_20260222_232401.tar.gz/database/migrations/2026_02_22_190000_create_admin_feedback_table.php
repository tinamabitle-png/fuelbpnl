<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('admin_feedback', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->text('message');
            $table->enum('sentiment', ['positive', 'neutral', 'negative'])->default('neutral');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('admin_feedback');
    }
};

