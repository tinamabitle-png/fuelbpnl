<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Settlement;
use App\Models\FuelStation;
use App\Models\FuelVoucher;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class SettlementController extends Controller
{
    /**
     * Display a listing of settlements.
     */
    public function index(Request $request)
    {
        $query = Settlement::with(['fuelStation'])
            ->withCount('vouchers');

        // Search
        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('reference', 'like', "%{$search}%")
                  ->orWhere('transaction_reference', 'like', "%{$search}%")
                  ->orWhereHas('fuelStation', function($q) use ($search) {
                      $q->where('name', 'like', "%{$search}%")
                        ->orWhere('company', 'like', "%{$search}%");
                  });
            });
        }

        // Filter by status
        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        // Filter by fuel station
        if ($request->has('fuel_station_id')) {
            $query->where('fuel_station_id', $request->fuel_station_id);
        }

        // Filter by date range
        if ($request->has('date_from')) {
            $query->whereDate('settlement_date', '>=', $request->date_from);
        }
        if ($request->has('date_to')) {
            $query->whereDate('settlement_date', '<=', $request->date_to);
        }

        // Sort
        $sort = $request->get('sort', 'created_at');
        $direction = $request->get('direction', 'desc');
        $query->orderBy($sort, $direction);

        $settlements = $query->paginate(20);
        $fuelStations = FuelStation::active()->get();

        // Calculate statistics
        $stats = [
            'total_settlements' => Settlement::count(),
            'total_amount' => Settlement::sum('amount'),
            'pending_amount' => Settlement::pending()->sum('amount'),
            'completed_amount' => Settlement::completed()->sum('amount'),
            'pending_count' => Settlement::pending()->count(),
            'completed_count' => Settlement::completed()->count(),
            'failed_count' => Settlement::failed()->count(),
        ];

        $brandPayouts = $this->buildBrandPayoutSummary();

        return view('admin.settlements.index', compact('settlements', 'fuelStations', 'stats', 'brandPayouts'));
    }

    /**
     * Show the form for creating a new settlement.
     */
    public function create(Request $request)
    {
        $fuelStations = FuelStation::active()->get();
        
        // If station_id is provided, get its pending vouchers
        $selectedStation = null;
        $pendingVouchers = collect();
        
        if ($request->has('station_id')) {
            $selectedStation = FuelStation::findOrFail($request->station_id);
            $pendingVouchers = $selectedStation->vouchers()
                ->where('status', 'redeemed')
                ->whereNull('settlement_id')
                ->latest()
                ->get();
        }

        return view('admin.settlements.create', compact('fuelStations', 'selectedStation', 'pendingVouchers'));
    }

    /**
     * Store a newly created settlement.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'fuel_station_id' => 'required|exists:fuel_stations,id',
            'amount' => 'required|numeric|min:0',
            'voucher_ids' => 'required|array',
            'voucher_ids.*' => 'exists:fuel_vouchers,id',
            'payment_method' => 'required|in:bank_transfer,mpesa,equity,airtel_money',
            'settlement_date' => 'required|date',
            'notes' => 'nullable|string',
        ]);

        // Validate that all vouchers belong to the selected station and are redeemable
        $vouchers = FuelVoucher::whereIn('id', $validated['voucher_ids'])
            ->where('fuel_station_id', $validated['fuel_station_id'])
            ->where('status', 'redeemed')
            ->whereNull('settlement_id')
            ->get();

        if ($vouchers->count() !== count($validated['voucher_ids'])) {
            return back()->with('error', 'Some vouchers are not available for direct bank deposit processing.');
        }

        // Calculate total amount from vouchers
        $totalAmount = $vouchers->sum('amount');
        
        if ($totalAmount != $validated['amount']) {
            return back()->with('error', 'Amount does not match total voucher amount.');
        }

        DB::transaction(function () use ($validated, $vouchers) {
            // Create the settlement
            $settlement = Settlement::create([
                'fuel_station_id' => $validated['fuel_station_id'],
                'amount' => $validated['amount'],
                'voucher_count' => count($validated['voucher_ids']),
                'status' => 'pending',
                'payment_method' => $validated['payment_method'],
                'settlement_date' => $validated['settlement_date'],
                'notes' => $validated['notes'] ?? null,
            ]);

            // Associate vouchers with this settlement
            $vouchers->each(function ($voucher) use ($settlement) {
                $voucher->update([
                    'settlement_id' => $settlement->id,
                    'settled_at' => now(),
                ]);
            });

            // Log the creation
            activity()
                ->performedOn($settlement)
                ->causedBy(auth()->user())
                ->withProperties([
                    'voucher_count' => $settlement->voucher_count,
                    'amount' => $settlement->amount,
                    'station' => $settlement->fuelStation->name,
                ])
                ->log('settlement_created');
        });

        return redirect()->route('admin.settlements.show', Settlement::latest()->first())
            ->with('success', 'Direct bank deposit created successfully. You can now process it.');
    }

    /**
     * Display the specified settlement.
     */
    public function show(Settlement $settlement)
    {
        $settlement->load(['fuelStation', 'vouchers.user']);
        
        return view('admin.settlements.show', compact('settlement'));
    }

    /**
     * Show the form for editing the specified settlement.
     */
    public function edit(Settlement $settlement)
    {
        if ($settlement->status !== 'pending') {
            return back()->with('error', 'Only pending direct bank deposits can be edited.');
        }

        $fuelStations = FuelStation::active()->get();
        $settlement->load('vouchers');
        
        return view('admin.settlements.edit', compact('settlement', 'fuelStations'));
    }

    /**
     * Update the specified settlement.
     */
    public function update(Request $request, Settlement $settlement)
    {
        if ($settlement->status !== 'pending') {
            return back()->with('error', 'Only pending direct bank deposits can be updated.');
        }

        $validated = $request->validate([
            'amount' => 'required|numeric|min:0',
            'payment_method' => 'required|in:bank_transfer,mpesa,equity,airtel_money',
            'settlement_date' => 'required|date',
            'notes' => 'nullable|string',
        ]);

        $settlement->update($validated);

        return redirect()->route('admin.settlements.show', $settlement)
            ->with('success', 'Direct bank deposit updated successfully.');
    }

    /**
     * Remove the specified settlement.
     */
    public function destroy(Settlement $settlement)
    {
        if ($settlement->status !== 'pending') {
            return back()->with('error', 'Only pending direct bank deposits can be deleted.');
        }

        DB::transaction(function () use ($settlement) {
            // Release vouchers back to unsettled state
            $settlement->vouchers()->update([
                'settlement_id' => null,
                'settled_at' => null,
            ]);

            // Delete the settlement
            $settlement->delete();
        });

        return redirect()->route('admin.settlements.index')
            ->with('success', 'Direct bank deposit deleted successfully.');
    }

    /**
     * Process a pending settlement.
     */
    public function process(Settlement $settlement)
    {
        if ($settlement->status !== 'pending') {
            return back()->with('error', 'Only pending direct bank deposits can be processed.');
        }

        try {
            DB::transaction(function () use ($settlement) {
                $settlement->process();
                
                // Log the processing
                activity()
                    ->performedOn($settlement)
                    ->causedBy(auth()->user())
                    ->withProperties([
                        'transaction_reference' => $settlement->transaction_reference,
                        'processed_at' => $settlement->processed_at,
                    ])
                    ->log('settlement_processed');
            });

            return back()->with('success', 'Direct bank deposit processed successfully. Station wallet has been credited.');
        } catch (\Exception $e) {
            return back()->with('error', 'Failed to process direct bank deposit: ' . $e->getMessage());
        }
    }

    /**
     * Mark settlement as failed.
     */
    public function markAsFailed(Request $request, Settlement $settlement)
    {
        if ($settlement->status !== 'pending') {
            return back()->with('error', 'Only pending direct bank deposits can be marked as failed.');
        }

        $validated = $request->validate([
            'reason' => 'required|string',
        ]);

        DB::transaction(function () use ($settlement, $validated) {
            $settlement->markAsFailed($validated['reason']);
            
            // Log the failure
            activity()
                ->performedOn($settlement)
                ->causedBy(auth()->user())
                ->withProperties(['reason' => $validated['reason']])
                ->log('settlement_failed');
        });

        return back()->with('success', 'Direct bank deposit marked as failed.');
    }

    /**
     * Bulk process settlements.
     */
    public function bulkProcess(Request $request)
    {
        $validated = $request->validate([
            'settlements' => 'required|array',
            'settlements.*' => 'exists:settlements,id',
        ]);

        $settlements = Settlement::whereIn('id', $validated['settlements'])
            ->pending()
            ->get();

        if ($settlements->isEmpty()) {
            return back()->with('error', 'No pending direct bank deposits selected.');
        }

        $successCount = 0;
        $failedCount = 0;

        foreach ($settlements as $settlement) {
            try {
                DB::transaction(function () use ($settlement) {
                    $settlement->process();
                });
                $successCount++;
            } catch (\Exception $e) {
                $failedCount++;
                \Log::error('Failed to process settlement ' . $settlement->id . ': ' . $e->getMessage());
            }
        }

        $message = "Processed {$successCount} direct bank deposits successfully.";
        if ($failedCount > 0) {
            $message .= " {$failedCount} direct bank deposits failed.";
        }

        return back()->with('success', $message);
    }

    /**
     * Process pending settlements for a selected retail brand (or all brands).
     */
    public function processBrand(Request $request)
    {
        $validated = $request->validate([
            'brand' => 'required|string|max:255',
        ]);

        $requestedBrand = trim((string) $validated['brand']);

        $pendingSettlements = Settlement::with('fuelStation')
            ->pending()
            ->whereHas('fuelStation')
            ->get();

        if ($pendingSettlements->isEmpty()) {
            return back()->with('error', 'No pending direct bank deposits available for brand processing.');
        }

        $targets = $pendingSettlements->filter(function (Settlement $settlement) use ($requestedBrand) {
            if ($requestedBrand === '__all__') {
                return true;
            }

            return strcasecmp($this->brandFromStation($settlement->fuelStation), $requestedBrand) === 0;
        });

        if ($targets->isEmpty()) {
            return back()->with('error', 'No pending direct bank deposits found for the selected retail brand.');
        }

        $processed = 0;
        $skipped = 0;
        $failed = 0;
        $totalAmount = 0.0;

        foreach ($targets as $settlement) {
            try {
                $station = $settlement->fuelStation;
                if (!$station || !$this->stationReadyForPayout($station)) {
                    $skipped++;
                    continue;
                }

                DB::transaction(function () use ($settlement, $station) {
                    $reference = $this->buildBrandTransferReference($settlement, $this->brandFromStation($station));

                    $settlement->update([
                        'status' => 'completed',
                        'processed_at' => now(),
                        'payment_method' => 'bank_transfer',
                        'transaction_reference' => $reference,
                        'notes' => trim((string) $settlement->notes . "\nBrand payout processed via direct deposit."),
                    ]);

                    $station->addToWallet((float) $settlement->amount, 'Brand payout settlement: ' . $settlement->reference);

                    activity()
                        ->performedOn($settlement)
                        ->causedBy(auth()->user())
                        ->withProperties([
                            'brand' => $this->brandFromStation($station),
                            'station_id' => $station->id,
                            'amount' => (float) $settlement->amount,
                            'transaction_reference' => $reference,
                        ])
                        ->log('brand_settlement_processed');
                });

                $processed++;
                $totalAmount += (float) $settlement->amount;
            } catch (\Throwable $e) {
                $failed++;
                report($e);
            }
        }

        $label = $requestedBrand === '__all__' ? 'all brands' : $requestedBrand;
        $message = sprintf(
            'Brand payout run complete for %s: %d processed (ZAR %s), %d skipped, %d failed.',
            $label,
            $processed,
            number_format($totalAmount, 2),
            $skipped,
            $failed
        );

        return back()->with($failed > 0 ? 'error' : 'success', $message);
    }

    /**
     * Export settlements to CSV.
     */
    public function export(Request $request)
    {
        $settlements = Settlement::with('fuelStation')->get();

        $filename = "settlements_" . date('Y-m-d_H-i-s') . ".csv";
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"$filename\"",
        ];

        $callback = function() use ($settlements) {
            $file = fopen('php://output', 'w');
            
            // Add BOM for UTF-8 compatibility
            fwrite($file, "\xEF\xBB\xBF");
            
            // Headers
            fputcsv($file, [
                'Reference', 'Station', 'Amount', 'Voucher Count', 'Status',
                'Payment Method', 'Settlement Date', 'Processed At',
                'Transaction Reference', 'Notes', 'Created At'
            ]);

            // Data
            foreach ($settlements as $settlement) {
                fputcsv($file, [
                    $settlement->reference,
                    $settlement->fuelStation->name,
                    $settlement->amount,
                    $settlement->voucher_count,
                    $settlement->status,
                    $settlement->payment_method,
                    $settlement->settlement_date->format('Y-m-d'),
                    $settlement->processed_at ? $settlement->processed_at->format('Y-m-d H:i:s') : '',
                    $settlement->transaction_reference ?? '',
                    $settlement->notes ?? '',
                    $settlement->created_at->format('Y-m-d H:i:s'),
                ]);
            }

            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }

    /**
     * Get pending settlement amount for a station.
     */
    public function getPendingAmount(Request $request)
    {
        $request->validate([
            'fuel_station_id' => 'required|exists:fuel_stations,id',
        ]);

        $station = FuelStation::findOrFail($request->fuel_station_id);
        $pendingAmount = $station->getPendingSettlementAmount();
        $pendingVouchers = $station->vouchers()
            ->where('status', 'redeemed')
            ->whereNull('settlement_id')
            ->count();

        return response()->json([
            'pending_amount' => $pendingAmount,
            'pending_vouchers' => $pendingVouchers,
        ]);
    }

    /**
     * Get settlement statistics.
     */
    public function statistics()
    {
        $totalSettlements = Settlement::count();
        $totalAmount = Settlement::sum('amount');
        
        $statusStats = Settlement::select('status', DB::raw('count(*) as count'), DB::raw('sum(amount) as amount'))
            ->groupBy('status')
            ->get();
            
        $dailyStats = Settlement::selectRaw('DATE(settlement_date) as date, count(*) as count, sum(amount) as amount')
            ->where('settlement_date', '>=', now()->subDays(30))
            ->groupBy('date')
            ->orderBy('date')
            ->get();
            
        $stationStats = Settlement::with('fuelStation')
            ->select('fuel_station_id', DB::raw('count(*) as count'), DB::raw('sum(amount) as amount'))
            ->groupBy('fuel_station_id')
            ->orderBy('amount', 'desc')
            ->limit(10)
            ->get();

        return response()->json([
            'total_settlements' => $totalSettlements,
            'total_amount' => $totalAmount,
            'status_stats' => $statusStats,
            'daily_stats' => $dailyStats,
            'station_stats' => $stationStats,
        ]);
    }

    private function brandFromStation(?FuelStation $station): string
    {
        if (!$station) {
            return 'Unassigned';
        }

        $brand = trim((string) ($station->company ?: $station->name ?: 'Unassigned'));
        return $brand !== '' ? $brand : 'Unassigned';
    }

    private function stationReadyForPayout(?FuelStation $station): bool
    {
        if (!$station) {
            return false;
        }

        $hasAccountNumber = trim((string) $station->payout_account_number) !== '';
        $hasBankInfo = trim((string) $station->payout_bank_code) !== '' || trim((string) $station->payout_bank_name) !== '';

        return $hasAccountNumber && $hasBankInfo;
    }

    private function buildBrandTransferReference(Settlement $settlement, string $brand): string
    {
        $slug = strtoupper(substr(preg_replace('/[^A-Za-z0-9]/', '', $brand), 0, 8));
        $slug = $slug !== '' ? $slug : 'BRAND';

        return sprintf(
            'BRAND-%s-%s-%s',
            $slug,
            now()->format('YmdHis'),
            str_pad((string) $settlement->id, 4, '0', STR_PAD_LEFT)
        );
    }

    private function buildBrandPayoutSummary()
    {
        $pending = Settlement::with('fuelStation')
            ->pending()
            ->whereHas('fuelStation')
            ->get();

        return $pending
            ->groupBy(fn (Settlement $settlement) => $this->brandFromStation($settlement->fuelStation))
            ->map(function ($items, $brand) {
                $count = $items->count();
                $amount = (float) $items->sum('amount');
                $readyCount = $items->filter(fn (Settlement $s) => $this->stationReadyForPayout($s->fuelStation))->count();

                return [
                    'brand' => $brand,
                    'count' => $count,
                    'amount' => $amount,
                    'ready_count' => $readyCount,
                    'blocked_count' => $count - $readyCount,
                ];
            })
            ->sortByDesc('amount')
            ->values();
    }
}
