<?php

namespace App\Http\Controllers\Driver;

use App\Http\Controllers\Controller;
use App\Events\VoucherStatusChanged;
use App\Models\FuelStation;
use App\Models\FuelVoucher;
use App\Models\Lease;
use App\Models\Repayment;
use App\Services\FuelPriceService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class DashboardController extends Controller
{
    private const MIN_REPAYMENT_AMOUNT = 30.00;

    public function __construct(private FuelPriceService $fuelPriceService)
    {
    }

    public function index()
    {
        $user = Auth::user();
        $this->authorizeDriverPortal($user);

        $activeVoucherCount = FuelVoucher::where('user_id', $user->id)
            ->whereIn('status', ['approved', 'issued'])
            ->count();

        $pendingRepayments = Repayment::where('user_id', $user->id)
            ->whereIn('status', ['pending', 'overdue'])
            ->count();

        $pendingRepaymentAmount = Repayment::where('user_id', $user->id)
            ->whereIn('status', ['pending', 'overdue'])
            ->sum('amount');

        $activeStationCount = FuelStation::where('status', 'active')->count();

        $latestApprovedVoucher = FuelVoucher::with('fuelStation')
            ->where('user_id', $user->id)
            ->where('status', 'approved')
            ->latest()
            ->first();

        $recentVouchers = FuelVoucher::with('fuelStation')
            ->where('user_id', $user->id)
            ->latest()
            ->limit(6)
            ->get();

        $upcomingRepayments = Repayment::with(['lease.vouchers.fuelStation'])
            ->where('user_id', $user->id)
            ->whereIn('status', ['pending', 'overdue'])
            ->orderBy('due_date')
            ->limit(8)
            ->get();

        $nextRepayment = $upcomingRepayments->first(function ($repayment) {
            return !empty($repayment->due_date);
        });
        $nextRepaymentCountdownTarget = $nextRepayment?->due_date
            ? \Illuminate\Support\Carbon::parse($nextRepayment->due_date)->endOfDay()->getTimestampMs()
            : null;

        return view('driver.dashboard', compact(
            'activeVoucherCount',
            'pendingRepayments',
            'pendingRepaymentAmount',
            'activeStationCount',
            'latestApprovedVoucher',
            'recentVouchers',
            'upcomingRepayments',
            'nextRepaymentCountdownTarget',
            'nextRepayment'
        ));
    }

    public function vouchers(Request $request)
    {
        $user = Auth::user();
        $this->authorizeDriverPortal($user);

        $stations = FuelStation::where('status', 'active')
            ->orderBy('name')
            ->get(['id', 'name']);

        $vouchers = FuelVoucher::with('fuelStation')
            ->where('user_id', $user->id)
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')->toString()))
            ->when($request->filled('station_id'), fn ($q) => $q->where('fuel_station_id', $request->integer('station_id')))
            ->latest()
            ->paginate(20)
            ->withQueryString();

        return view('driver.vouchers.index', compact('vouchers', 'stations'));
    }

    public function createVoucher()
    {
        $this->authorizeDriverPortal(Auth::user());

        $stationsPayload = Cache::remember('driver:voucher:stations-payload:v1', now()->addMinute(), function () {
            $stations = FuelStation::where('status', 'active')
                ->orderBy('name')
                ->get(['id', 'name', 'city', 'latitude', 'longitude']);

            $defaults = $this->fuelPriceService->defaultPrices();
            $priceRowsByStation = collect();

            if (Schema::hasTable('fuel_station_prices') && $stations->isNotEmpty()) {
                $stationIds = $stations->pluck('id')->all();
                $supportedFuelTypes = array_keys($defaults);
                $hasActiveColumn = Schema::hasColumn('fuel_station_prices', 'is_active');

                // Fetch only the latest row per station + fuel type.
                $latestIds = DB::table('fuel_station_prices as fsp')
                    ->selectRaw('MAX(fsp.id) as id')
                    ->whereIn('fsp.fuel_station_id', $stationIds)
                    ->whereIn('fsp.fuel_type', $supportedFuelTypes)
                    ->when($hasActiveColumn, fn ($q) => $q->where('fsp.is_active', true))
                    ->groupBy('fsp.fuel_station_id', 'fsp.fuel_type');

                $priceRowsByStation = DB::table('fuel_station_prices as fsp')
                    ->joinSub($latestIds, 'latest', function ($join) {
                        $join->on('fsp.id', '=', 'latest.id');
                    })
                    ->select('fsp.fuel_station_id', 'fsp.fuel_type', 'fsp.price_per_liter')
                    ->get()
                    ->groupBy('fuel_station_id');
            }

            return $stations->map(function ($station) use ($defaults, $priceRowsByStation) {
                $prices = $defaults;
                foreach (($priceRowsByStation[$station->id] ?? collect()) as $row) {
                    $fuelType = (string) ($row->fuel_type ?? '');
                    if (!array_key_exists($fuelType, $prices)) {
                        continue;
                    }
                    $prices[$fuelType] = (float) $row->price_per_liter;
                }

                return [
                    'id' => $station->id,
                    'name' => $station->name,
                    'city' => $station->city,
                    'latitude' => $station->latitude,
                    'longitude' => $station->longitude,
                    'prices' => $prices,
                ];
            })->values();
        });

        $leaseDefaults = Cache::remember('driver:voucher:lease-defaults:v1', now()->addMinutes(5), function () {
            $settingMap = DB::table('settings')
                ->whereIn('key', ['lease_interest_rate', 'lease_term_days'])
                ->pluck('value', 'key');

            $baseRate = (float) ($settingMap['lease_interest_rate'] ?? 5);
            $baseTerm = (int) ($settingMap['lease_term_days'] ?? 30);
            $baseTerm = max(7, min(60, $baseTerm));

            return [
                'rate' => $baseRate,
                'term_days' => $baseTerm,
                'min_days' => 7,
                'max_days' => 60,
                'rate_per_day' => 0.05,
                'min_daily_repayment' => self::MIN_REPAYMENT_AMOUNT,
            ];
        });

        return view('driver.vouchers.create', compact('stationsPayload', 'leaseDefaults'));
    }

    public function storeVoucher(Request $request)
    {
        $user = Auth::user();
        $this->authorizeDriverPortal($user);

        $validated = $request->validate([
            'fuel_station_id' => 'required|exists:fuel_stations,id',
            'amount' => 'required|numeric|min:100|max:100000',
            'fuel_type' => 'required|in:petrol,diesel,super',
            'liters' => 'nullable|numeric|min:0.1|max:5000',
            'repayment_days' => 'nullable|integer|min:7|max:60',
            'voucher_reference' => 'nullable|string|max:120',
            'card_reference' => 'nullable|string|max:50',
        ]);

        $resolvedPrice = $this->fuelPriceService->resolvePriceForStationFuel(
            (int) $validated['fuel_station_id'],
            (string) $validated['fuel_type'],
            true
        );
        $pricePerLiter = (float) ($resolvedPrice['price'] ?? 25.00);

        $liters = (float) ($validated['liters'] ?? 0);
        if ($liters <= 0) {
            $basePrice = (float) ($pricePerLiter ?: 25.00);
            $liters = round(((float) $validated['amount']) / max($basePrice, 0.01), 3);
        }

        $settingMap = DB::table('settings')
            ->whereIn('key', ['lease_interest_rate', 'lease_term_days'])
            ->pluck('value', 'key');

        $baseRate = (float) ($settingMap['lease_interest_rate'] ?? 5);
        $baseTerm = (int) ($settingMap['lease_term_days'] ?? 30);
        $baseTerm = max(7, min(60, $baseTerm));
        $termDays = (int) ($validated['repayment_days'] ?? $baseTerm);
        $termDays = max(7, min(60, $termDays));
        $rate = $this->calculateLeaseRate($baseRate, $baseTerm, $termDays);
        $principal = (float) $validated['amount'];
        $interestAmount = round($principal * ($rate / 100), 2);
        $totalAmount = round($principal + $interestAmount, 2);
        $dailyRepayment = round($totalAmount / max($termDays, 1), 2);
        if ($dailyRepayment < self::MIN_REPAYMENT_AMOUNT) {
            throw ValidationException::withMessages([
                'repayment_days' => sprintf(
                    'Repayment per day cannot be below R%.2f. Increase amount or reduce repayment days.',
                    self::MIN_REPAYMENT_AMOUNT
                ),
            ]);
        }

        $createdVoucher = null;

        DB::transaction(function () use ($user, $validated, $liters, $principal, $rate, $interestAmount, $totalAmount, $termDays, $dailyRepayment, &$createdVoucher) {
            $lease = Lease::create([
                'user_id' => $user->id,
                'principal_amount' => $principal,
                'interest_rate' => $rate,
                'interest_amount' => $interestAmount,
                'total_amount' => $totalAmount,
                'term_days' => $termDays,
                'daily_repayment' => $dailyRepayment,
                'status' => 'active',
                'issued_at' => now(),
                'due_date' => now()->addDays($termDays)->toDateString(),
            ]);

            $createdVoucher = FuelVoucher::create([
                'user_id' => $user->id,
                'fuel_station_id' => $validated['fuel_station_id'],
                'lease_id' => $lease->id,
                'amount' => $principal,
                'liters' => $liters,
                'fuel_type' => $validated['fuel_type'],
                'status' => 'issued',
                'issued_at' => now(),
                'expires_at' => now()->addHours(24),
                'transaction_reference' => $validated['voucher_reference'] ?? null,
                'pump_number' => $validated['card_reference'] ?? null,
            ]);
        });

        if ($createdVoucher) {
            $voucher = $createdVoucher->fresh(['user:id,name,phone', 'fuelStation:id,name,city']);

            try {
                event(new VoucherStatusChanged([
                    'event' => 'issued',
                    'voucher_id' => $voucher->id,
                    'voucher_code' => $voucher->code,
                    'qr_code' => $voucher->qr_code,
                    'status' => $voucher->status,
                    'amount' => (float) $voucher->amount,
                    'fuel_type' => $voucher->fuel_type,
                    'liters' => (float) $voucher->liters,
                    'station_id' => $voucher->fuel_station_id,
                    'station' => [
                        'id' => $voucher->fuelStation?->id,
                        'name' => $voucher->fuelStation?->name,
                        'city' => $voucher->fuelStation?->city,
                    ],
                    'driver' => [
                        'id' => $voucher->user?->id,
                        'name' => $voucher->user?->name,
                        'phone' => $voucher->user?->phone,
                    ],
                    'issued_at' => optional($voucher->issued_at)->toIso8601String(),
                    'expires_at' => optional($voucher->expires_at)->toIso8601String(),
                    'redeemed_at' => optional($voucher->redeemed_at)->toIso8601String(),
                    'pump_number' => $voucher->pump_number,
                    'transaction_reference' => $voucher->transaction_reference,
                ]));
            } catch (\Throwable $e) {
                report($e);
            }
        }

        return redirect()
            ->route('driver.vouchers.index')
            ->with('success', 'Voucher request submitted successfully.');
    }

    public function repayments()
    {
        $user = Auth::user();
        $this->authorizeDriverPortal($user);

        $repayments = Repayment::with(['lease.vouchers.fuelStation'])
            ->where('user_id', $user->id)
            ->orderByRaw("FIELD(status, 'overdue','pending','paid','defaulted')")
            ->orderBy('due_date')
            ->paginate(20);

        $summary = [
            'pending_count' => Repayment::where('user_id', $user->id)->whereIn('status', ['pending', 'overdue'])->count(),
            'pending_amount' => Repayment::where('user_id', $user->id)->whereIn('status', ['pending', 'overdue'])->sum('amount'),
            'paid_this_month' => Repayment::where('user_id', $user->id)
                ->where('status', 'paid')
                ->whereMonth('paid_at', now()->month)
                ->whereYear('paid_at', now()->year)
                ->sum('amount'),
        ];

        return view('driver.repayments.index', compact('repayments', 'summary'));
    }

    public function profile()
    {
        $user = Auth::user()->load(['wallet', 'creditLimit']);
        $this->authorizeDriverPortal($user);

        $summary = [
            'total_vouchers' => FuelVoucher::where('user_id', $user->id)->count(),
            'redeemed_vouchers' => FuelVoucher::where('user_id', $user->id)->where('status', 'redeemed')->count(),
            'active_leases' => Lease::where('user_id', $user->id)->where('status', 'active')->count(),
            'paid_repayments' => Repayment::where('user_id', $user->id)->where('status', 'paid')->count(),
        ];

        return view('driver.profile', compact('user', 'summary'));
    }

    public function payRepayment(Request $request, Repayment $repayment)
    {
        $user = Auth::user();
        $this->authorizeDriverPortal($user);

        if ((int) $repayment->user_id !== (int) $user->id) {
            abort(403);
        }

        if (!in_array($repayment->status, ['pending', 'overdue'], true)) {
            return back()->with('error', 'Repayment has already been processed.');
        }

        $method = $request->input('payment_method', 'card');
        if (!in_array($method, ['apple_pay', 'google_pay', 'card'], true)) {
            $method = 'card';
        }

        $repayment->markAsPaid("paystack_{$method}", 'PAYSTACK-' . strtoupper(Str::random(10)));

        if ($user->wallet) {
            $debit = min((float) $repayment->amount, (float) $user->wallet->outstanding_balance);
            if ($debit > 0) {
                $user->wallet->decrement('outstanding_balance', $debit);
            }
            $user->wallet->increment('total_repayments', (float) $repayment->amount);
        }

        if ($user->creditLimit) {
            $user->creditLimit->releaseCredit((float) $repayment->amount);
        }

        if ($repayment->lease && $repayment->lease->remaining_balance <= 0 && $repayment->lease->status === 'active') {
            $repayment->lease->update([
                'status' => 'completed',
                'completed_at' => now(),
            ]);
        }

        return back()->with('success', 'Repayment processed successfully.');
    }

    private function authorizeDriverPortal($user): void
    {
        abort_unless($user && $user->hasAnyRole(['super_admin', 'admin', 'driver']), 403);
    }

    private function calculateLeaseRate(float $baseRate, int $baseTermDays, int $selectedTermDays): float
    {
        $deltaDays = $selectedTermDays - $baseTermDays;
        $rate = $baseRate + ($deltaDays * 0.05);

        return round(max(1, min(35, $rate)), 2);
    }
}
